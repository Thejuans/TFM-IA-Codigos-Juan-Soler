"""End-to-end demo comparing four approaches on an imbalanced binary problem:

1. an unweighted ``LogisticRegression`` (reference),
2. ``LogisticRegression(class_weight="balanced")`` (sklearn's inverse-frequency heuristic),
3. an **exhaustive** ``GridSearchCV`` over both class weights (the brute-force baseline),
4. ``GreedyClassWeightLogisticRegressionCV`` (coarse-to-fine search over the same box).

The greedy search should match the exhaustive grid's quality while evaluating far
fewer weight pairs, and tune the weights to the chosen metric (balanced accuracy)
rather than relying on the fixed inverse-frequency heuristic.
"""

import numpy as np
from sklearn.datasets import make_classification
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import balanced_accuracy_score, classification_report
from sklearn.model_selection import (
    GridSearchCV,
    StratifiedKFold,
    cross_val_score,
    train_test_split,
)
from sklearn.utils.class_weight import compute_class_weight

from greedy_logreg import GreedyClassWeightLogisticRegressionCV


def _unique_weight_evaluations(cv_results):
    """Number of distinct (w_neg, w_pos) pairs the greedy search actually scored."""
    points = set()
    for rd in cv_results:
        for wn, wp in rd["weights"]:
            points.add((round(float(wn), 8), round(float(wp), 8)))
    return len(points)


def main():
    X, y = make_classification(
        n_samples=3000,
        n_features=20,
        n_informative=5,
        weights=[0.9, 0.1],
        random_state=0,
    )
    Xtr, Xte, ytr, yte = train_test_split(
        X, y, test_size=0.3, stratify=y, random_state=0
    )

    # Identical folds and metric for every approach -> a fair comparison.
    cv = StratifiedKFold(n_splits=5)
    scoring = "balanced_accuracy"
    bounds = (0.1, 10.0)

    def make_lr(**kw):
        return LogisticRegression(max_iter=1000, random_state=0, **kw)

    def cv_score(est):
        return cross_val_score(est, Xtr, ytr, scoring=scoring, cv=cv).mean()

    # 1) Unweighted reference.
    plain = make_lr().fit(Xtr, ytr)
    plain_cv = cv_score(make_lr())

    # 2) sklearn's inverse-frequency heuristic (no search).
    balanced = make_lr(class_weight="balanced").fit(Xtr, ytr)
    balanced_cv = cv_score(make_lr(class_weight="balanced"))
    bw = compute_class_weight("balanced", classes=np.array([0, 1]), y=ytr)

    # 3) Exhaustive grid search over both class weights, on the same box the
    #    greedy search explores (21 x 21 = 441 weight pairs, 0.1-dex spacing).
    weight_axis = np.logspace(np.log10(bounds[0]), np.log10(bounds[1]), 21)
    class_weight_grid = [
        {0: float(wn), 1: float(wp)} for wn in weight_axis for wp in weight_axis
    ]
    grid = GridSearchCV(
        make_lr(),
        param_grid={"class_weight": class_weight_grid},
        scoring=scoring,
        cv=cv,
        n_jobs=-1,
    ).fit(Xtr, ytr)

    # 4) Greedy coarse-to-fine search over the same box.
    greedy = GreedyClassWeightLogisticRegressionCV(
        weight_bounds=bounds,
        cv=cv,
        scoring=scoring,
        max_iter=1000,
        random_state=0,
    ).fit(Xtr, ytr)
    greedy_evals = _unique_weight_evaluations(greedy.cv_results_)

    rows = [
        ("unweighted LR", 1, plain_cv, plain),
        ("LR class_weight='balanced'", 1, balanced_cv, balanced),
        ("exhaustive grid search", len(class_weight_grid), grid.best_score_, grid),
        ("greedy refinement", greedy_evals, greedy.best_score_, greedy),
    ]
    print(f"{'model':<28}{'weight pairs':>13}{'CV bal-acc':>12}{'test bal-acc':>15}")
    print("-" * 68)
    for name, evals, cv_sc, model in rows:
        test_ba = balanced_accuracy_score(yte, model.predict(Xte))
        print(f"{name:<28}{evals:>13}{cv_sc:>12.4f}{test_ba:>15.4f}")

    print()
    print(f"sklearn 'balanced' weights    : {{0: {bw[0]:.3f}, 1: {bw[1]:.3f}}}")
    print(f"grid-search best class_weight : {grid.best_params_['class_weight']}")
    print(f"greedy      best class_weight : {greedy.best_class_weight_}")
    print(
        f"\ngreedy reached comparable quality with {greedy_evals} weight pairs vs "
        f"{len(class_weight_grid)} for the exhaustive grid "
        f"({len(class_weight_grid) / greedy_evals:.1f}x fewer evaluations)."
    )

    print("\n=== greedy weighted ===")
    print(classification_report(yte, greedy.predict(Xte), digits=3))
    print("=== LR class_weight='balanced' ===")
    print(classification_report(yte, balanced.predict(Xte), digits=3))
    print("=== unweighted baseline ===")
    print(classification_report(yte, plain.predict(Xte), digits=3))


if __name__ == "__main__":
    main()
