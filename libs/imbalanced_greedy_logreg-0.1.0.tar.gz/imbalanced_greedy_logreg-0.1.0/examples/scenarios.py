"""Compare three class-weighting strategies across increasingly hard scenarios.

Methods (all selected on the SAME stratified folds and balanced-accuracy metric):

* ``balanced LR``    -- ``LogisticRegression(class_weight="balanced")``, the fixed
                        inverse-frequency heuristic (no search).
* ``exhaustive grid``-- ``GridSearchCV`` over a dense 21x21 grid of both class weights.
* ``greedy``         -- ``GreedyClassWeightLogisticRegressionCV``, coarse-to-fine search.

Three scenarios crank up the difficulty together: rarer minority class, more class
overlap, more noise features, and a more fragmented decision boundary. The question
is whether *searching* the weights (and tuning them to the metric) increasingly beats
the fixed heuristic -- and whether greedy keeps matching the exhaustive grid cheaply.
"""

import warnings

import numpy as np
from sklearn.datasets import make_classification
from sklearn.exceptions import ConvergenceWarning
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import balanced_accuracy_score
from sklearn.model_selection import (
    GridSearchCV,
    StratifiedKFold,
    cross_val_score,
    train_test_split,
)

from greedy_logreg import GreedyClassWeightLogisticRegressionCV

warnings.filterwarnings("ignore", category=ConvergenceWarning)

# Shared search box and the exhaustive grid built on it (0.1-dex spacing -> 441 pairs).
BOUNDS = (0.1, 10.0)
GRID_AXIS = np.logspace(np.log10(BOUNDS[0]), np.log10(BOUNDS[1]), 21)
CLASS_WEIGHT_GRID = [{0: float(a), 1: float(b)} for a in GRID_AXIS for b in GRID_AXIS]

SCENARIOS = [
    (
        "A  mild imbalance, well separated",
        dict(
            n_samples=4000, n_features=20, n_informative=8, n_redundant=2,
            weights=[0.90, 0.10], class_sep=1.5, n_clusters_per_class=1,
            flip_y=0.0, random_state=0,
        ),
    ),
    (
        "B  strong imbalance, overlapping",
        dict(
            n_samples=4000, n_features=30, n_informative=6, n_redundant=4,
            weights=[0.97, 0.03], class_sep=0.8, n_clusters_per_class=2,
            flip_y=0.01, random_state=1,
        ),
    ),
    (
        "C  severe imbalance, noisy & overlapping",
        dict(
            n_samples=6000, n_features=40, n_informative=5, n_redundant=10,
            weights=[0.99, 0.01], class_sep=0.5, n_clusters_per_class=3,
            flip_y=0.02, random_state=2,
        ),
    ),
]


def _unique_weight_evaluations(cv_results):
    """Distinct (w_neg, w_pos) pairs the greedy search actually scored."""
    points = set()
    for rd in cv_results:
        for wn, wp in rd["weights"]:
            points.add((round(float(wn), 8), round(float(wp), 8)))
    return len(points)


def run_scenario(kwargs):
    X, y = make_classification(**kwargs)
    Xtr, Xte, ytr, yte = train_test_split(
        X, y, test_size=0.3, stratify=y, random_state=42
    )
    cv = StratifiedKFold(n_splits=5)
    scoring = "balanced_accuracy"

    def make_lr(**kw):
        return LogisticRegression(max_iter=2000, random_state=0, **kw)

    # 1) Fixed inverse-frequency heuristic.
    balanced = make_lr(class_weight="balanced").fit(Xtr, ytr)
    balanced_cv = cross_val_score(
        make_lr(class_weight="balanced"), Xtr, ytr, scoring=scoring, cv=cv
    ).mean()

    # 2) Exhaustive grid search over both weights.
    grid = GridSearchCV(
        make_lr(), {"class_weight": CLASS_WEIGHT_GRID}, scoring=scoring, cv=cv, n_jobs=-1
    ).fit(Xtr, ytr)

    # 3) Greedy coarse-to-fine search over the same box.
    greedy = GreedyClassWeightLogisticRegressionCV(
        weight_bounds=BOUNDS, cv=cv, scoring=scoring, max_iter=2000, random_state=0
    ).fit(Xtr, ytr)

    return {
        "minority_pct": 100.0 * float(np.mean(ytr == 1)),
        "rows": [
            ("balanced LR", 1, balanced_cv,
             balanced_accuracy_score(yte, balanced.predict(Xte))),
            ("exhaustive grid", len(CLASS_WEIGHT_GRID), grid.best_score_,
             balanced_accuracy_score(yte, grid.predict(Xte))),
            ("greedy refinement", _unique_weight_evaluations(greedy.cv_results_),
             greedy.best_score_, balanced_accuracy_score(yte, greedy.predict(Xte))),
        ],
    }


def print_summary(summary):
    """Consolidated report across all scenarios (held-out test balanced accuracy)."""
    width = 96
    print("\n" + "=" * width)
    print(
        "SUMMARY — held-out test balanced accuracy "
        "(greedy cost = weight pairs evaluated vs the exhaustive grid)"
    )
    print("=" * width)
    print(
        f"{'scenario':<42}{'minority':>9}{'balanced':>10}"
        f"{'grid':>9}{'greedy':>9}{'greedy cost':>17}"
    )
    print("-" * width)
    for name, res in summary:
        balanced_test = res["rows"][0][3]
        grid_evals, grid_test = res["rows"][1][1], res["rows"][1][3]
        greedy_evals, greedy_test = res["rows"][2][1], res["rows"][2][3]
        cost = f"{greedy_evals} vs {grid_evals} ({grid_evals / greedy_evals:.1f}x)"
        print(
            f"{name:<42}{res['minority_pct']:>8.1f}%{balanced_test:>10.4f}"
            f"{grid_test:>9.4f}{greedy_test:>9.4f}{cost:>17}"
        )
    print("=" * width)


def main():
    summary = []
    for name, kwargs in SCENARIOS:
        res = run_scenario(kwargs)
        print(f"\n{name}   (minority = {res['minority_pct']:.1f}% of train)")
        print(f"  {'method':<20}{'weight pairs':>13}{'CV bal-acc':>12}{'test bal-acc':>15}")
        print("  " + "-" * 60)
        for label, evals, cv_sc, test_ba in res["rows"]:
            print(f"  {label:<20}{evals:>13}{cv_sc:>12.4f}{test_ba:>15.4f}")
        grid_evals = res["rows"][1][1]
        greedy_evals = res["rows"][2][1]
        print(
            f"  -> greedy matched the grid using {greedy_evals} vs {grid_evals} "
            f"weight pairs ({grid_evals / greedy_evals:.1f}x fewer)"
        )
        summary.append((name, res))

    print_summary(summary)


if __name__ == "__main__":
    main()
