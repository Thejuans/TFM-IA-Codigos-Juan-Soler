"""Behavioral tests for GreedyClassWeightLogisticRegressionCV."""

import numpy as np
import pytest
from sklearn.datasets import make_classification
from sklearn.exceptions import NotFittedError
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import balanced_accuracy_score
from sklearn.model_selection import train_test_split

from greedy_logreg import GreedyClassWeightLogisticRegressionCV, gmean_scorer


@pytest.fixture
def imbalanced_data():
    return make_classification(
        n_samples=2000,
        n_features=20,
        n_informative=5,
        n_redundant=2,
        weights=[0.9, 0.1],
        n_classes=2,
        random_state=0,
    )


def test_beats_unweighted_baseline_and_upweights_minority(imbalanced_data):
    X, y = imbalanced_data
    Xtr, Xte, ytr, yte = train_test_split(
        X, y, test_size=0.3, stratify=y, random_state=0
    )
    clf = GreedyClassWeightLogisticRegressionCV(
        n_points=5, n_iter=4, cv=3, max_iter=1000, random_state=0
    ).fit(Xtr, ytr)
    base = LogisticRegression(max_iter=1000, random_state=0).fit(Xtr, ytr)

    ba_clf = balanced_accuracy_score(yte, clf.predict(Xte))
    ba_base = balanced_accuracy_score(yte, base.predict(Xte))
    assert ba_clf >= ba_base
    # minority class (1) should be up-weighted relative to majority (0)
    assert clf.best_class_weight_[1] > clf.best_class_weight_[0]


def test_more_than_two_classes_raises():
    X3, y3 = make_classification(
        n_samples=300, n_features=20, n_informative=6, n_classes=3, random_state=0
    )
    with pytest.raises(ValueError, match="binary"):
        GreedyClassWeightLogisticRegressionCV(n_iter=1, cv=3).fit(X3, y3)


def test_convergence_attributes(imbalanced_data):
    X, y = imbalanced_data
    clf = GreedyClassWeightLogisticRegressionCV(
        n_iter=5, n_points=3, cv=3, max_iter=500, random_state=0
    ).fit(X, y)
    assert 1 <= clf.n_rounds_ <= 5
    assert len(clf.cv_results_) == clf.n_rounds_
    assert np.isfinite(clf.best_score_)
    for rd in clf.cv_results_:
        assert np.all(np.isfinite(rd["scores"]))


def test_large_score_tol_stops_early(imbalanced_data):
    X, y = imbalanced_data
    clf = GreedyClassWeightLogisticRegressionCV(
        n_iter=10, score_tol=1.0, n_points=3, cv=3, max_iter=500, random_state=0
    ).fit(X, y)
    assert clf.n_rounds_ < 10


def test_gmean_scoring_runs(imbalanced_data):
    X, y = imbalanced_data
    clf = GreedyClassWeightLogisticRegressionCV(
        scoring=gmean_scorer(), n_iter=3, n_points=3, cv=3, max_iter=500, random_state=0
    ).fit(X, y)
    assert clf.best_class_weight_[1] >= clf.best_class_weight_[0]


def test_scoring_none_defaults_to_balanced_accuracy(imbalanced_data):
    X, y = imbalanced_data
    clf = GreedyClassWeightLogisticRegressionCV(
        scoring=None, n_iter=2, n_points=3, cv=3, max_iter=500, random_state=0
    ).fit(X, y)
    assert np.isfinite(clf.best_score_)


def test_sample_weight_flows_through(imbalanced_data):
    X, y = imbalanced_data
    sw = np.ones(len(y))
    sw[y == 1] = 3.0
    clf = GreedyClassWeightLogisticRegressionCV(
        n_iter=2, n_points=3, cv=3, max_iter=500, random_state=0
    )
    clf.fit(X, y, sample_weight=sw)
    assert hasattr(clf, "best_weights_")


def test_predict_before_fit_raises():
    clf = GreedyClassWeightLogisticRegressionCV()
    with pytest.raises(NotFittedError):
        clf.predict(np.zeros((3, 4)))


def test_refit_false_disables_predict(imbalanced_data):
    X, y = imbalanced_data
    clf = GreedyClassWeightLogisticRegressionCV(
        refit=False, n_iter=2, n_points=3, cv=3, max_iter=500, random_state=0
    ).fit(X, y)
    assert hasattr(clf, "best_weights_")
    assert not hasattr(clf, "estimator_")
    with pytest.raises(AttributeError):
        clf.predict(X)


def test_predict_proba_and_decision_function(imbalanced_data):
    X, y = imbalanced_data
    clf = GreedyClassWeightLogisticRegressionCV(
        n_iter=2, n_points=3, cv=3, max_iter=500, random_state=0
    ).fit(X, y)
    proba = clf.predict_proba(X)
    assert proba.shape == (len(y), 2)
    assert np.allclose(proba.sum(axis=1), 1.0)
    assert clf.decision_function(X).shape == (len(y),)


@pytest.mark.slow
def test_full_defaults_run(imbalanced_data):
    X, y = imbalanced_data
    clf = GreedyClassWeightLogisticRegressionCV(max_iter=1000, random_state=0).fit(X, y)
    assert np.isfinite(clf.best_score_)
