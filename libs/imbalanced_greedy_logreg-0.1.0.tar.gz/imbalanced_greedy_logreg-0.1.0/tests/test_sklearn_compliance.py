"""scikit-learn API compliance tests."""

import numpy as np
from sklearn.base import clone
from sklearn.datasets import make_classification
from sklearn.model_selection import GridSearchCV
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.utils.estimator_checks import parametrize_with_checks

from greedy_logreg import GreedyClassWeightLogisticRegressionCV


def _fast_est(**kw):
    params = dict(n_points=3, n_iter=2, cv=3, max_iter=200)
    params.update(kw)
    return GreedyClassWeightLogisticRegressionCV(**params)


def test_clone():
    clone(_fast_est())


def test_get_set_params_roundtrip():
    est = _fast_est(n_points=4)
    params = est.get_params()
    est2 = GreedyClassWeightLogisticRegressionCV().set_params(**params)
    assert est2.get_params()["n_points"] == 4
    assert est2.get_params()["cv"] == 3


def test_works_in_pipeline():
    X, y = make_classification(n_samples=300, weights=[0.85, 0.15], random_state=0)
    pipe = Pipeline([("sc", StandardScaler()), ("clf", _fast_est())])
    pipe.fit(X, y)
    assert pipe.predict(X).shape == y.shape


def test_works_in_gridsearch():
    X, y = make_classification(n_samples=300, weights=[0.85, 0.15], random_state=0)
    gs = GridSearchCV(_fast_est(), param_grid={"C": [0.1, 1.0]}, cv=3)
    gs.fit(X, y)
    assert hasattr(gs, "best_estimator_")
    assert np.isfinite(gs.best_score_)


@parametrize_with_checks([_fast_est()])
def test_sklearn_common_checks(estimator, check):
    check(estimator)
