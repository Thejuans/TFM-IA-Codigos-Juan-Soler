"""Unit tests for the pure greedy-search helpers (no model fitting)."""

import numpy as np
import pytest

from greedy_logreg._search import (
    _argmax_tiebreak,
    _axis,
    _clip,
    _key,
    _resolve_bounds,
    greedy_search,
)


def test_axis_log_endpoints_and_geometric_spacing():
    nodes = _axis(0.1, 10.0, 5, log_scale=True)
    assert nodes.shape == (5,)
    assert nodes[0] == pytest.approx(0.1)
    assert nodes[-1] == pytest.approx(10.0)
    ratios = nodes[1:] / nodes[:-1]
    assert np.allclose(ratios, ratios[0])  # constant ratio == log spacing


def test_axis_linear():
    nodes = _axis(0.0, 1.0, 5, log_scale=False)
    assert np.allclose(nodes, [0.0, 0.25, 0.5, 0.75, 1.0])


def test_clip_never_escapes_global_bounds():
    assert _clip(-1.0, 100.0, 0.1, 10.0) == (0.1, 10.0)
    assert _clip(0.5, 5.0, 0.1, 10.0) == (0.5, 5.0)
    # best-on-edge: window pushed past the top is clamped
    assert _clip(8.0, 20.0, 0.1, 10.0) == (8.0, 10.0)


def test_key_rounds_for_memoization():
    assert _key((1.0000000001, 2.0), 4) == (1.0, 2.0)


def test_argmax_tiebreak_prefers_least_extreme():
    grid = [(0.1, 10.0), (1.0, 1.0), (10.0, 0.1)]
    scores = np.array([1.0, 1.0, 1.0])  # all tied
    assert _argmax_tiebreak(scores, grid) == 1  # (1.0, 1.0) is least extreme


def test_resolve_bounds_tuple_applies_to_both_axes():
    bn, bp = _resolve_bounds((0.2, 5.0), np.array([0, 0, 1, 1]), np.array([0, 1]))
    assert bn == (0.2, 5.0)
    assert bp == (0.2, 5.0)


def test_resolve_bounds_balanced_centers_each_axis():
    y = np.array([0] * 90 + [1] * 10)
    bn, bp = _resolve_bounds("balanced", y, np.array([0, 1]))
    # center_neg = 100 / (2*90) ~ 0.5556 ; center_pos = 100 / (2*10) = 5.0
    assert bn[0] == pytest.approx(0.5556 / 10, rel=1e-2)
    assert bp == pytest.approx((0.5, 50.0))


def _peak_at_one(base_params, X, y, classes, p, scorer, splits, sample_weight):
    """Stub score: unimodal peak at (w_neg, w_pos) == (1, 1) in log space."""
    return -((np.log10(p[0])) ** 2 + (np.log10(p[1])) ** 2)


def test_cache_prevents_recomputing_overlapping_points():
    calls = []

    def counting(*args):
        p = args[4]
        calls.append(_key(p, 8))
        return _peak_at_one(*args)

    best_w, best_s, history = greedy_search(
        base_params={}, X=None, y=np.array([0, 1]), classes=np.array([0, 1]),
        scorer=None, splits=None, sample_weight=None,
        weight_bounds=(0.1, 10.0), n_points=5, n_iter=4, shrink=0.5,
        score_tol=0.0, log_scale=True, cache_decimals=8, n_jobs=None,
        score_fn=counting,
    )
    # the incumbent (1, 1) recurs every round but must be scored only once
    assert len(calls) == len(set(calls))
    assert best_w == pytest.approx((1.0, 1.0))


def test_convergence_stops_before_n_iter():
    best_w, best_s, history = greedy_search(
        base_params={}, X=None, y=np.array([0, 1]), classes=np.array([0, 1]),
        scorer=None, splits=None, sample_weight=None,
        weight_bounds=(0.1, 10.0), n_points=5, n_iter=20, shrink=0.5,
        score_tol=1e-6, log_scale=True, cache_decimals=8, n_jobs=None,
        score_fn=_peak_at_one,
    )
    assert len(history) < 20  # flat optimum -> early stop
    assert best_w[0] == pytest.approx(1.0, abs=0.5)
    assert best_w[1] == pytest.approx(1.0, abs=0.5)
