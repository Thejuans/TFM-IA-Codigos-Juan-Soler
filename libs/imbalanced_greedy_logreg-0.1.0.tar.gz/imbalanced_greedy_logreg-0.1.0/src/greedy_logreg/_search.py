"""Pure, stateless helpers implementing the greedy 2D class-weight search.

These functions deliberately hold no estimator state so they can be unit-tested
in isolation and pickled for joblib parallelism. The search refines a coarse grid
over both class weights ``(w_neg, w_pos)`` into denser grids around the running
best, until the best cross-validation score stops improving.
"""

from __future__ import annotations

import numpy as np
from joblib import Parallel, delayed
from sklearn.base import clone
from sklearn.linear_model import LogisticRegression

__all__ = [
    "greedy_search",
    "_resolve_bounds",
    "_axis",
    "_clip",
    "_key",
    "_argmax_tiebreak",
    "_score_weight",
]


def _resolve_bounds(weight_bounds, y, classes):
    """Return per-axis global search bounds ``((lo_n, hi_n), (lo_p, hi_p))``.

    A ``(w_min, w_max)`` tuple is applied to both axes. The string ``"balanced"``
    centres each axis one decade around ``n / (2 * n_c)`` (sklearn's balanced
    weight for that class).
    """
    if isinstance(weight_bounds, str):  # "balanced"
        y = np.asarray(y)
        n = y.shape[0]
        per_axis = []
        for c in classes:
            n_c = int(np.sum(y == c))
            center = n / (2.0 * n_c)
            per_axis.append((center / 10.0, center * 10.0))
        return per_axis[0], per_axis[1]
    lo, hi = float(weight_bounds[0]), float(weight_bounds[1])
    return (lo, hi), (lo, hi)


def _axis(lo, hi, n_points, log_scale):
    """Nodes for one weight axis: log-spaced (default) or linearly spaced."""
    if log_scale:
        return np.logspace(np.log10(lo), np.log10(hi), n_points)
    return np.linspace(lo, hi, n_points)


def _clip(lo, hi, gmin, gmax):
    """Keep a window inside the global bounds."""
    return max(lo, gmin), min(hi, gmax)


def _key(point, decimals):
    """Robust memoization key for a ``(w_neg, w_pos)`` point."""
    return (round(float(point[0]), decimals), round(float(point[1]), decimals))


def _argmax_tiebreak(scores, grid):
    """Index of the best score; ties broken toward least-extreme reweighting.

    "Least extreme" = log-weights closest to the origin, i.e. weights closest to
    1.0, which keeps the selection stable and reproducible.
    """
    scores = np.asarray(scores, dtype=float)
    best = scores.max()
    tied = np.flatnonzero(scores >= best - 1e-12)
    if tied.size == 1:
        return int(tied[0])

    def extremity(i):
        wn, wp = grid[i]
        return np.log10(wn) ** 2 + np.log10(wp) ** 2

    return int(min(tied, key=extremity))


def _score_weight(base_params, X, y, classes, weights, scorer, splits, sample_weight):
    """Mean cross-validation score for a single ``(w_neg, w_pos)`` point.

    Uses an explicit fold loop (rather than ``cross_val_score``) so that
    ``sample_weight`` flows into each training fold without relying on metadata
    routing. Folds are pre-materialized and shared across all points so weight
    comparisons are fair and cache-valid.
    """
    class_weight = {classes[0]: float(weights[0]), classes[1]: float(weights[1])}
    base = LogisticRegression(**base_params)
    base.set_params(class_weight=class_weight)

    fold_scores = []
    for train, test in splits:
        model = clone(base)
        if sample_weight is None:
            model.fit(X[train], y[train])
        else:
            model.fit(X[train], y[train], sample_weight=sample_weight[train])
        fold_scores.append(scorer(model, X[test], y[test]))
    return float(np.mean(fold_scores))


def greedy_search(
    *,
    base_params,
    X,
    y,
    classes,
    scorer,
    splits,
    sample_weight,
    weight_bounds,
    n_points,
    n_iter,
    shrink,
    score_tol,
    log_scale,
    cache_decimals,
    n_jobs,
    score_fn=None,
):
    """Greedy coarse-to-fine search over both class weights.

    Returns ``(best_weights, best_score, history)`` where ``best_weights`` is the
    ``(w_neg, w_pos)`` tuple, and ``history`` is a list of per-round dicts with
    keys ``round``, ``bounds``, ``weights``, ``scores``, ``best_weights``,
    ``best_score`` for inspection/plotting.

    ``score_fn`` defaults to :func:`_score_weight`; it is injectable so the search
    logic can be unit-tested without fitting real models.
    """
    if score_fn is None:
        score_fn = _score_weight

    (gn_lo, gn_hi), (gp_lo, gp_hi) = _resolve_bounds(weight_bounds, y, classes)

    if log_scale:
        to_log = np.log10
        from_log = lambda v: 10.0 ** v  # noqa: E731
    else:
        to_log = lambda v: v  # noqa: E731
        from_log = lambda v: v  # noqa: E731

    lo_n, hi_n = gn_lo, gn_hi
    lo_p, hi_p = gp_lo, gp_hi

    cache = {}
    history = []
    best_w, best_s = None, -np.inf
    prev_best_s = None

    for r in range(n_iter):
        axis_n = _axis(lo_n, hi_n, n_points, log_scale)
        axis_p = _axis(lo_p, hi_p, n_points, log_scale)
        grid = [(float(wn), float(wp)) for wn in axis_n for wp in axis_p]

        uncached = [p for p in grid if _key(p, cache_decimals) not in cache]
        if uncached:
            results = Parallel(n_jobs=n_jobs)(
                delayed(score_fn)(
                    base_params, X, y, classes, p, scorer, splits, sample_weight
                )
                for p in uncached
            )
            for p, s in zip(uncached, results):
                cache[_key(p, cache_decimals)] = s

        round_scores = np.array([cache[_key(p, cache_decimals)] for p in grid])
        i = _argmax_tiebreak(round_scores, grid)
        round_best_w = grid[i]
        round_best_s = float(round_scores[i])

        history.append(
            {
                "round": r,
                "bounds": ((lo_n, hi_n), (lo_p, hi_p)),
                "weights": np.array(grid, dtype=float),
                "scores": round_scores,
                "best_weights": round_best_w,
                "best_score": round_best_s,
            }
        )

        if round_best_s > best_s:
            best_s, best_w = round_best_s, round_best_w

        # --- convergence checks ---
        if prev_best_s is not None and abs(round_best_s - prev_best_s) < score_tol:
            break  # best score "changes little"
        if not uncached:
            break  # window fully cached -> no movement possible
        prev_best_s = round_best_s

        # --- zoom: tighter window centred on this round's best ---
        center_n, center_p = to_log(round_best_w[0]), to_log(round_best_w[1])
        half_n = (to_log(hi_n) - to_log(lo_n)) / 2.0 * shrink
        half_p = (to_log(hi_p) - to_log(lo_p)) / 2.0 * shrink
        if max(half_n, half_p) < 1e-9:
            break  # window negligibly small
        lo_n, hi_n = _clip(
            from_log(center_n - half_n), from_log(center_n + half_n), gn_lo, gn_hi
        )
        lo_p, hi_p = _clip(
            from_log(center_p - half_p), from_log(center_p + half_p), gp_lo, gp_hi
        )

    return best_w, best_s, history
