"""A LogisticRegressionCV-style estimator that greedily searches class weights."""

from __future__ import annotations

import numbers

from sklearn.base import BaseEstimator, ClassifierMixin, _fit_context
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import check_scoring
from sklearn.model_selection import check_cv
from sklearn.utils._param_validation import Interval, StrOptions
from sklearn.utils.multiclass import (
    check_classification_targets,
    type_of_target,
    unique_labels,
)
from sklearn.utils.validation import (
    _check_sample_weight,
    check_is_fitted,
    validate_data,
)

from ._search import greedy_search

# LogisticRegression keyword arguments passed straight through to every fit.
# Deliberately excludes ``class_weight`` (owned by the search) and the deprecated
# ``penalty``/``multi_class`` (regularization type is set via ``l1_ratio``; this
# estimator is binary-only). ``random_state`` is added separately so it can be
# forwarded in one place.
_LOGREG_PARAMS = (
    "C",
    "dual",
    "tol",
    "fit_intercept",
    "intercept_scaling",
    "solver",
    "max_iter",
    "l1_ratio",
    "warm_start",
    "verbose",
)


class GreedyClassWeightLogisticRegressionCV(ClassifierMixin, BaseEstimator):
    """Logistic regression that tunes class weights by greedy grid refinement.

    Analogous to :class:`~sklearn.linear_model.LogisticRegressionCV`, but instead
    of tuning ``C`` it searches the two class weights ``(w_neg, w_pos)`` for
    imbalanced **binary** classification. A coarse log-spaced grid is scored by
    cross-validation, the best point is found, then a denser grid is built in its
    neighbourhood; this repeats until the best score changes by less than
    ``score_tol`` (or ``n_iter`` rounds are reached).

    Parameters
    ----------
    weight_bounds : tuple of float or "balanced", default=(0.1, 10.0)
        Global per-axis search range applied to both class weights. ``"balanced"``
        centres each axis one decade around ``n / (2 * n_c)``.
    n_points : int, default=5
        Number of grid nodes per axis per round (``n_points**2`` fits/round).
    n_iter : int, default=5
        Maximum number of coarse-to-fine rounds.
    shrink : float, default=0.5
        Per-axis log half-width multiplier between rounds (the zoom factor).
    score_tol : float, default=1e-4
        Stop when the best CV score improves by less than this between rounds.
        Distinct from ``tol`` (the LogisticRegression optimizer tolerance).
    log_scale : bool, default=True
        Use log-spaced grids (recommended, weights act multiplicatively).
    cache_decimals : int, default=8
        Decimals used to round ``(w_neg, w_pos)`` memoization keys.
    scoring : str or callable, default="balanced_accuracy"
        Any sklearn scorer string or a ``make_scorer`` callable. ``None`` is
        coerced to ``"balanced_accuracy"`` (never falls back to plain accuracy).
    cv : int, cross-validation generator or iterable, default=5
        Resolved with ``classifier=True`` so integers give ``StratifiedKFold``.
    n_jobs : int or None, default=None
        Parallelism across grid points (joblib).
    refit : bool, default=True
        If True, refit the final ``LogisticRegression`` on all data at the best
        weights. If False, only the search attributes are populated.
    random_state : int, RandomState or None, default=None
        Forwarded to the underlying ``LogisticRegression``.
    C, dual, tol, fit_intercept, intercept_scaling, solver, max_iter, l1_ratio, \
            warm_start, verbose
        Passed through verbatim to every underlying ``LogisticRegression``. The
        regularization type is controlled by ``l1_ratio`` (0.0=L2, 1.0=L1,
        in-between=elastic-net), matching scikit-learn >=1.8.

    Attributes
    ----------
    classes_ : ndarray of shape (2,)
        The two class labels.
    best_weights_ : tuple of float
        The selected ``(w_neg, w_pos)``.
    best_class_weight_ : dict
        ``{classes_[0]: w_neg, classes_[1]: w_pos}`` (keyed by real labels).
    best_score_ : float
        Best mean cross-validation score.
    cv_results_ : list of dict
        One entry per round with the grid, scores, bounds and round best.
    n_rounds_ : int
        Number of refinement rounds actually run.
    scorer_ : callable
        The resolved scorer used for selection.
    estimator_ : LogisticRegression
        The final refit model (only if ``refit=True``).
    coef_, intercept_, n_iter_ : ndarray
        Exposed from ``estimator_`` when refit.
    """

    _parameter_constraints = {
        "weight_bounds": [tuple, StrOptions({"balanced"})],
        "n_points": [Interval(numbers.Integral, 2, None, closed="left")],
        "n_iter": [Interval(numbers.Integral, 1, None, closed="left")],
        "shrink": [Interval(numbers.Real, 0.0, 1.0, closed="right")],
        "score_tol": [Interval(numbers.Real, 0.0, None, closed="left")],
        "log_scale": ["boolean"],
        "cache_decimals": [Interval(numbers.Integral, 0, None, closed="left")],
        "scoring": [str, callable, None],
        "cv": ["cv_object"],
        "n_jobs": [numbers.Integral, None],
        "refit": ["boolean"],
        "random_state": ["random_state"],
        "C": [Interval(numbers.Real, 0, None, closed="neither")],
        "dual": ["boolean"],
        "tol": [Interval(numbers.Real, 0, None, closed="neither")],
        "fit_intercept": ["boolean"],
        "intercept_scaling": [Interval(numbers.Real, 0, None, closed="neither")],
        "solver": [
            StrOptions(
                {
                    "lbfgs",
                    "liblinear",
                    "newton-cg",
                    "newton-cholesky",
                    "sag",
                    "saga",
                }
            )
        ],
        "max_iter": [Interval(numbers.Integral, 1, None, closed="left")],
        "l1_ratio": [Interval(numbers.Real, 0, 1, closed="both")],
        "warm_start": ["boolean"],
        "verbose": [Interval(numbers.Integral, 0, None, closed="left")],
    }

    def __init__(
        self,
        *,
        weight_bounds=(0.1, 10.0),
        n_points=5,
        n_iter=5,
        shrink=0.5,
        score_tol=1e-4,
        log_scale=True,
        cache_decimals=8,
        scoring="balanced_accuracy",
        cv=5,
        n_jobs=None,
        refit=True,
        random_state=None,
        C=1.0,
        dual=False,
        tol=1e-4,
        fit_intercept=True,
        intercept_scaling=1.0,
        solver="lbfgs",
        max_iter=100,
        l1_ratio=0.0,
        warm_start=False,
        verbose=0,
    ):
        self.weight_bounds = weight_bounds
        self.n_points = n_points
        self.n_iter = n_iter
        self.shrink = shrink
        self.score_tol = score_tol
        self.log_scale = log_scale
        self.cache_decimals = cache_decimals
        self.scoring = scoring
        self.cv = cv
        self.n_jobs = n_jobs
        self.refit = refit
        self.random_state = random_state
        self.C = C
        self.dual = dual
        self.tol = tol
        self.fit_intercept = fit_intercept
        self.intercept_scaling = intercept_scaling
        self.solver = solver
        self.max_iter = max_iter
        self.l1_ratio = l1_ratio
        self.warm_start = warm_start
        self.verbose = verbose

    def _base_params(self):
        """LogisticRegression kwargs (incl. random_state), excluding class_weight."""
        params = {name: getattr(self, name) for name in _LOGREG_PARAMS}
        params["random_state"] = self.random_state
        return params

    def _make_base_estimator(self):
        return LogisticRegression(**self._base_params())

    def __sklearn_tags__(self):
        tags = super().__sklearn_tags__()
        tags.classifier_tags.multi_class = False  # binary-only
        tags.target_tags.required = True
        tags.input_tags.sparse = True
        return tags

    @_fit_context(prefer_skip_nested_validation=False)
    def fit(self, X, y, sample_weight=None):
        X, y = validate_data(
            self, X, y, accept_sparse="csr", dtype="numeric", reset=True
        )
        check_classification_targets(y)
        y_type = type_of_target(y, input_name="y", raise_unknown=True)
        self.classes_ = unique_labels(y)
        if self.classes_.shape[0] < 2:
            raise ValueError(
                "Classifier can't train when only one class is present in the "
                f"data; got class {self.classes_.tolist()}."
            )
        if y_type != "binary":
            raise ValueError(
                "Only binary classification is supported. The type of the target "
                f"is {y_type}."
            )
        if sample_weight is not None:
            sample_weight = _check_sample_weight(sample_weight, X)

        self.scorer_ = check_scoring(
            self._make_base_estimator(), scoring=self.scoring or "balanced_accuracy"
        )
        cv = check_cv(self.cv, y, classifier=True)
        splits = list(cv.split(X, y))  # materialize once -> identical folds everywhere

        best_w, best_s, history = greedy_search(
            base_params=self._base_params(),
            X=X,
            y=y,
            classes=self.classes_,
            scorer=self.scorer_,
            splits=splits,
            sample_weight=sample_weight,
            weight_bounds=self.weight_bounds,
            n_points=self.n_points,
            n_iter=self.n_iter,
            shrink=self.shrink,
            score_tol=self.score_tol,
            log_scale=self.log_scale,
            cache_decimals=self.cache_decimals,
            n_jobs=self.n_jobs,
        )

        self.best_weights_ = best_w
        labels = self.classes_.tolist()  # native Python scalars for clean keys
        self.best_class_weight_ = {labels[0]: best_w[0], labels[1]: best_w[1]}
        self.best_score_ = best_s
        self.cv_results_ = history
        self.n_rounds_ = len(history)

        if self.refit:
            self.estimator_ = self._make_base_estimator()
            self.estimator_.set_params(class_weight=self.best_class_weight_)
            if sample_weight is not None:
                self.estimator_.fit(X, y, sample_weight=sample_weight)
            else:
                self.estimator_.fit(X, y)
            self.coef_ = self.estimator_.coef_
            self.intercept_ = self.estimator_.intercept_
            self.n_iter_ = self.estimator_.n_iter_

        return self

    def _check_refit(self):
        if not hasattr(self, "estimator_"):
            raise AttributeError(
                "This estimator was fitted with refit=False, so it has no "
                "underlying model. Refit with refit=True (the default) to predict."
            )

    def predict(self, X):
        check_is_fitted(self)
        self._check_refit()
        X = validate_data(self, X, accept_sparse="csr", reset=False)
        return self.estimator_.predict(X)

    def predict_proba(self, X):
        check_is_fitted(self)
        self._check_refit()
        X = validate_data(self, X, accept_sparse="csr", reset=False)
        return self.estimator_.predict_proba(X)

    def predict_log_proba(self, X):
        check_is_fitted(self)
        self._check_refit()
        X = validate_data(self, X, accept_sparse="csr", reset=False)
        return self.estimator_.predict_log_proba(X)

    def decision_function(self, X):
        check_is_fitted(self)
        self._check_refit()
        X = validate_data(self, X, accept_sparse="csr", reset=False)
        return self.estimator_.decision_function(X)
