"""Convenience scorer factories for imbalance-aware selection metrics."""

from __future__ import annotations

from imblearn.metrics import geometric_mean_score
from sklearn.metrics import make_scorer

__all__ = ["gmean_scorer"]


def gmean_scorer(**kwargs):
    """Scorer for imbalanced-learn's geometric mean of class recalls.

    For binary problems the default ``average='multiclass'`` returns the true
    G-mean ``sqrt(sensitivity * specificity)``. Pass through any
    :func:`imblearn.metrics.geometric_mean_score` keyword (e.g. ``pos_label``).

    Example
    -------
    >>> from greedy_logreg import GreedyClassWeightLogisticRegressionCV, gmean_scorer
    >>> clf = GreedyClassWeightLogisticRegressionCV(scoring=gmean_scorer())
    """
    return make_scorer(geometric_mean_score, **kwargs)
