"""Greedy class-weight LogisticRegressionCV for imbalanced binary classification."""

from ._estimator import GreedyClassWeightLogisticRegressionCV
from .metrics import gmean_scorer

# Short, ergonomic alias.
GreedyWeightLogRegCV = GreedyClassWeightLogisticRegressionCV

__version__ = "0.1.0"

__all__ = [
    "GreedyClassWeightLogisticRegressionCV",
    "GreedyWeightLogRegCV",
    "gmean_scorer",
    "__version__",
]
