# imbalanced-greedy-logreg

A scikit-learn–compatible logistic-regression solver that finds **optimal class
weights** for **imbalanced binary classification** using a **greedy successive grid
refinement** search — analogous to `LogisticRegressionCV`, but tuning class weights
instead of `C`.

## How it works

`GreedyClassWeightLogisticRegressionCV` searches the two class weights
`(w_neg, w_pos)` over a 2D grid:

1. Score a **coarse** log-spaced grid of weight pairs by cross-validation
   (default metric: **balanced accuracy**).
2. Find the best pair.
3. Build a **denser** grid in a shrinking neighbourhood around the best pair.
4. Repeat until the best score changes by less than `score_tol` (or `n_iter`
   rounds are reached).

Already-evaluated weight pairs are memoized, so overlapping refined grids never
recompute the same point.

## Installation

The package needs **Python ≥ 3.13** and installs `scikit-learn`, `imbalanced-learn`
and `numpy` automatically.

### Anaconda on Windows (recommended for students)

First get the code: either `git clone <repo-url>` or download the ZIP from the repo
page and unzip it. Then open the **Anaconda Prompt** (Start menu → "Anaconda Prompt")
and run:

```bat
:: 1. create and activate a dedicated environment with Python 3.13
conda create -n greedy-logreg -c conda-forge python=3.13
conda activate greedy-logreg

:: 2. go into the project folder (the one that contains pyproject.toml)
cd path\to\imbalanced_greedy_logreg

:: 3. install this package in editable mode (pulls in scikit-learn etc.)
pip install -e .

:: ...or, if you also want to run the tests:
pip install -e ".[dev]"
```

`-e` (editable) means Python imports the code straight from this folder, so any edit
you make is picked up without reinstalling.

> **Prefer conda packages for the heavy libraries?** Install them with conda first,
> then add this package without re-resolving its dependencies:
> ```bat
> conda create -n greedy-logreg -c conda-forge python=3.13 scikit-learn imbalanced-learn numpy
> conda activate greedy-logreg
> pip install -e . --no-deps
> ```

To check it worked:

```bat
python -c "import greedy_logreg; print(greedy_logreg.__version__)"
```

### uv (maintainer workflow)

```bash
uv sync --extra dev          # creates a local .venv with runtime + dev deps
```

## Quick start

With the `greedy-logreg` environment **activated**:

```python
from sklearn.datasets import make_classification
from greedy_logreg import GreedyClassWeightLogisticRegressionCV

X, y = make_classification(n_samples=2000, weights=[0.9, 0.1], random_state=0)

clf = GreedyClassWeightLogisticRegressionCV(random_state=0).fit(X, y)
print(clf.best_class_weight_)   # selected weights, e.g. {0: 0.1, 1: 0.75}
print(clf.best_score_)          # best CV balanced accuracy
print(clf.n_rounds_)            # refinement rounds run
clf.predict(X)
clf.predict_proba(X)
```

> **Using Jupyter or Spyder (from Anaconda)?** Launch them from inside the activated
> environment (`conda activate greedy-logreg`, then `jupyter lab` / `spyder`), or pick
> the **greedy-logreg** kernel, so that `import greedy_logreg` resolves.

### Choosing the selection metric

Any scikit-learn scorer string or callable works via `scoring`. To select on
imbalanced-learn's geometric mean of class recalls:

```python
from greedy_logreg import GreedyClassWeightLogisticRegressionCV, gmean_scorer

clf = GreedyClassWeightLogisticRegressionCV(scoring=gmean_scorer()).fit(X, y)
```

## Key parameters

| Parameter | Default | Meaning |
|---|---|---|
| `weight_bounds` | `(0.1, 10.0)` | Per-axis search range for each class weight (or `"balanced"`). |
| `n_points` | `5` | Grid nodes per axis per round. |
| `n_iter` | `5` | Maximum coarse-to-fine rounds. |
| `shrink` | `0.5` | Per-round zoom factor on the (log) window. |
| `score_tol` | `1e-4` | Stop when the best CV score improves by less than this. |
| `scoring` | `"balanced_accuracy"` | Selection metric (any sklearn scorer / callable). |
| `cv` | `5` | Cross-validation (ints → `StratifiedKFold`). |
| `n_jobs` | `None` | Parallel workers across grid points (`-1` = all cores). |
| `refit` | `True` | Refit the final model on all data at the best weights. |

Standard `LogisticRegression` parameters (`C`, `solver`, `max_iter`, `l1_ratio`,
…) are passed straight through. The regularization type is set via `l1_ratio`
(`0.0`=L2, `1.0`=L1, in-between=elastic-net), matching scikit-learn ≥1.8.

> Note: the greedy stop tolerance is `score_tol`; the LogisticRegression optimizer
> tolerance remains `tol`.

## Running the examples

Two runnable comparisons live in `examples/`. With the environment activated:

```bat
python examples\demo.py        :: greedy vs. balanced LR vs. exhaustive GridSearchCV
python examples\scenarios.py   :: the same 3 methods across increasingly hard datasets
```

(On macOS/Linux use forward slashes, e.g. `python examples/demo.py`.)

> **Windows + `n_jobs=-1`:** Windows starts worker processes by *re-importing* your
> script, so any script that uses parallelism must guard its entry point with
> `if __name__ == "__main__":` (the bundled examples already do). Without it you can
> get a `RuntimeError` about a process being started before the current one finished
> bootstrapping.

## Running the tests

```bat
pytest -q                 :: full test suite (needs the [dev] extra installed)
pytest -m "not slow" -q   :: skip the slow default-config run
```

Under uv: `uv run pytest -q`.
